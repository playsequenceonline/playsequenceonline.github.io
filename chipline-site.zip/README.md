# Chipline

A five-in-a-row card board game for 2 to 12 players, in 2 or 3 teams.
Play online from your own phones with a room code, or pass one device around.

- `index.html`: the whole game (rules, board, effects, online rooms).
- `config.js`: the online settings. It holds only the public Supabase key, which is safe to publish.

The game server and database run on Supabase.
